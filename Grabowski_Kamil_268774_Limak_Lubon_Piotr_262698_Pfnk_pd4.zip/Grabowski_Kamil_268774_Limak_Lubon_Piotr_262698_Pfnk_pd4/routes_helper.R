library(ggplot2)


col_from_per <- function(p)
{
  ifelse(p <= 10, 1, ifelse(p <= 15, 2, ifelse(p <= 20, 3, ifelse(p <= 25, 4, 5))))
}
col_from_avg<- function(p)
{
  ifelse(p <= 5, 1, ifelse(p <= 10, 2, ifelse(p <= 15, 3, 4)))
}
plot_routes_percent <- function(routes)
{
  routes$percent <- as.factor(col_from_per(routes$percent))
  worldmap <- borders("world",xlim = c(-200, -20), ylim = c(20, 55), colour="#efede1", fill="#efede1")
  ggplot() + worldmap +
    geom_curve(data=routes, aes(x = from.lon, y = from.lat, xend = to.lon, yend = to.lat, colour = percent),  size = 0.2, curvature = .2) + 
    scale_colour_manual(labels= c('<= 10 %', '10% - 15%', '15% - 20%', '20% - 25%', '>25%'), 
                        values=c('green', 'purple', 'blue', 'orange', 'red'))+
    theme(panel.background = element_rect(fill="white"), 
          axis.line = element_blank(),
          axis.text.x = element_blank(),
          axis.text.y = element_blank(),
          axis.ticks = element_blank(),
          axis.title.x = element_blank(),
          axis.title.y = element_blank(),
          legend.title = element_blank(),
          legend.position = 'left'
    ) 
}

plot_routes_avg <- function(routes)
{
  routes$percent <- as.factor(col_from_avg(routes$percent))
  routes <- routes[complete.cases(routes), ]
  worldmap <- borders("world",xlim = c(-200, -20), ylim = c(20, 55), colour="#efede1", fill="#efede1")
  ggplot() + worldmap +
    geom_curve(data=routes, aes(x = from.lon, y = from.lat, xend = to.lon, yend = to.lat, colour = percent),  size = 0.2, curvature = .2) + 
    scale_colour_manual(labels= c('<= 5 %', '5% - 10%', '10% - 15%', '>15%'), 
                        values=c('green', 'purple', 'blue', 'red'))+
    theme(panel.background = element_rect(fill="white"), 
          axis.line = element_blank(),
          axis.text.x = element_blank(),
          axis.text.y = element_blank(),
          axis.ticks = element_blank(),
          axis.title.x = element_blank(),
          axis.title.y = element_blank(),
          legend.title = element_blank(),
          legend.position = 'left'
    ) 
}

plot_routes<- function(routes)
{
  worldmap <- borders("world",xlim = c(-200, -20), ylim = c(20, 55), colour="#efede1", fill="#efede1")
  ggplot() + worldmap +
    geom_curve(data=routes, aes(x = from.lon, y = from.lat, xend = to.lon, yend = to.lat),  size = 0.2, curvature = .2) + 
    theme(panel.background = element_rect(fill="white"), 
          axis.line = element_blank(),
          axis.text.x = element_blank(),
          axis.text.y = element_blank(),
          axis.ticks = element_blank(),
          axis.title.x = element_blank(),
          axis.title.y = element_blank(),
          legend.title = element_blank(),
    ) 
}